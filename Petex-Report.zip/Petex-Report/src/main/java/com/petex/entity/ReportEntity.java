package com.petex.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "REPORT-TAB")
public class ReportEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long petId;

	private String userName;

	private String userEmail;

	private String address;

	private Long userMoblieNumber;

	private String petName;

	private String petType;

	private String petBreed;

	private String petColour;

	private LocalDate dateOfLost;

	@CreationTimestamp
	private LocalDate date;

	@CreationTimestamp
	private LocalTime times;

	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getUserMoblieNumber() {
		return userMoblieNumber;
	}

	public void setUserMoblieNumber(Long userMoblieNumber) {
		this.userMoblieNumber = userMoblieNumber;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetType() {
		return petType;
	}

	public void setPetType(String petType) {
		this.petType = petType;
	}

	public String getPetBreed() {
		return petBreed;
	}

	public void setPetBreed(String petBreed) {
		this.petBreed = petBreed;
	}

	public String getPetColour() {
		return petColour;
	}

	public void setPetColour(String petColour) {
		this.petColour = petColour;
	}

	public LocalDate getDateOfLost() {
		return dateOfLost;
	}

	public void setDateOfLost(LocalDate dateOfLost) {
		this.dateOfLost = dateOfLost;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getTimes() {
		return times;
	}

	public void setTimes(LocalTime times) {
		this.times = times;
	}

	public ReportEntity(Long petId, String userName, String userEmail, String address, Long userMoblieNumber,
			String petName, String petType, String petBreed, String petColour, LocalDate dateOfLost, LocalDate date,
			LocalTime times) {
		super();
		this.petId = petId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.address = address;
		this.userMoblieNumber = userMoblieNumber;
		this.petName = petName;
		this.petType = petType;
		this.petBreed = petBreed;
		this.petColour = petColour;
		this.dateOfLost = dateOfLost;
		this.date = date;
		this.times = times;
	}

	public ReportEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
