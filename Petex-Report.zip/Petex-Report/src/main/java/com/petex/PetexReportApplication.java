package com.petex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetexReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetexReportApplication.class, args);
	}

}
