package com.petex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetexUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
